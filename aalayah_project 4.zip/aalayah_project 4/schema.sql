DROP TABLE IF EXISTS users;
/* table for users*/
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    username TEXT NOT NULL,
    pass TEXT NOT NULL,
    phone_number INTEGER NOT NULL,
    email TEXT NOT NULL
);

CREATE TABLE saved (
    recipe_id INTEGER PRIMARY KEY,
    email INTEGER,
    FOREIGN KEY (email)
        REFERENCES  user(email)
)



