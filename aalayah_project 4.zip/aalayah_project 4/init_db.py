import sqlite3
#Creates connection with database
connection = sqlite3.connect('database.db')


with open('schema.sql') as f:
    connection.executescript(f.read())

#Creates cursor for db
cur = connection.cursor()

#adds in inital values for the database
cur.execute("INSERT INTO users (username, pass, phone_number,email) VALUES (?, ? ,? , ?)",
            ('Aalayah', 'test',5097684265,'aalayah4265@gmail.com')
            )

cur.execute("INSERT INTO saved (recipe_id,email) VALUES (?, ?)",
            (716429, 'aalayah4265@gmail.com')
            )

#commits the changes to the db and closes the connection
connection.commit()
connection.close()
