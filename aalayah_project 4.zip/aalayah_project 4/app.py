from crypt import methods
from flask_session import Session
import re
import email
from email.mime import image
from flask import Flask, render_template ,request, url_for, flash, redirect, session
import sqlite3
import requests
import uuid
from flask import Flask
import phonenumbers
global id1
#base url for api calls
searchUrl = 'https://api.spoonacular.com/recipes/complexSearch?apiKey=3cded965754b4c3f9abc835d812259d3&query='
global recipeURL
recipeURL = 'https://api.spoonacular.com/recipes/'
global recipeURL2
recipeURL2 = '/information?apiKey=3cded965754b4c3f9abc835d812259d3'

#Connects to sqlite database , use connection object for db operations 
def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

app = Flask(__name__)
app.config['SECRET_KEY'] = uuid.uuid4().hex #Forgot why I needed this, but I refuse to take it out
app.config["TEMPLATES_AUTO_RELOAD"] = True #Auto reload page
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)


#Default page , currently displays the list of current users 
@app.route('/')
def index():
        #Get the featured recipe
        #button to log in 
        conn = get_db_connection()
        users = conn.execute('SELECT * FROM users').fetchall()
        saved = conn.execute('SELECT * FROM saved').fetchall()
        conn.close()
        return render_template('index.html', users=users,saved=saved)


#Renders search page when url for search is called
@app.route('/search',methods=('GET','POST'))
def search():
        if request.method == 'POST':
            title = request.form['title']
            if not title:
                flash('Title is required!')
            else:
                #API call to get the search results, refine with filters later
                r = requests.get(searchUrl+title)
                data = r.json()
                global results 
                results = data['results']
                return redirect(url_for('searchResults'))
        return render_template('search.html')

@app.route('/searchResults')
def searchResults():
        #Displays the search results
        print(results)
        for key in results:
            print(key["title"])
        return render_template('searchResults.html',recipes=results)

@app.route('/recipeInfo/<int:id>')
def recipeInfo(id):
    id = str(id)
    url = recipeURL + id + recipeURL2
    print(url)
    r = requests.get(url)
    data = r.json() # changing into dict
    components = data['extendedIngredients'] # setting data = to everything in extended Ingredients
    print(data)
    print("\n")
    print(components)
    ing = [] #array 
    for key in components: 
        ing.append(key['original'])
    print(ing)
    # #api call for the rest of the recipe's info 
    # #add heart button to save the recipe
    #  print(data)
    return render_template('recipeInfo.html',id=id, recipe=data, ing=ing)




@app.route('/saveRecipe/<int:id>')
def saveRecipe(id):
        try:
            #adds the recipe to the db
            connection = sqlite3.connect('database.db')
            cur = connection.cursor()
            cur.execute("INSERT INTO saved (recipe_id,email) VALUES (?, ?)",(id,session.get("email")))
            connection.commit()
            connection.close()
        except:
            print('An error has occured')
        return render_template('recipeInfo.html')
        #Add other info from schema(title and picture)

@app.route('/login' ,methods=('GET','POST'))
def login():
    if request.method == 'POST':
        session['email'] = request.form['email']
        return redirect(url_for('account'))
    return render_template('login.html')
    
@app.route('/account')
def account():
        conn = get_db_connection()
        saved = conn.execute('SELECT * FROM saved').fetchall()
        conn.close()
        #account page
        return render_template('account.html',email=session.get("email"),saved=saved)

@app.route('/logout')
def logout():
    session.pop('email', None)
    return redirect(url_for('login'))


@app.route('/makeAccount',methods=('GET','POST'))
def makeAccount():
    #Can only be accessed if not already logged in
    #gets and assigns the forms data
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            phoneNumber = request.form['phoneNumber']
            email = request.form['email']
            if not username:
                flash('Title is required!')
            else:
                #makes sure all the form data is correct and creates the account
                if(validateForm(username,password,phoneNumber,email)):
                    createAccount(username,password,phoneNumber,email)
                    
        return render_template('makeAccount.html')


def validateForm(username,password,phoneNumber,email):
    #Checks to see the length of the username and password 
    if(len(username) <= 16 and len(username) >=8 and len(password) <= 16 and len(password) >=8 ):
        phoneNumber1 = ''.join(('+1',phoneNumber)) #adds in an area code , needs to be touched up later
        phone_number = phonenumbers.parse(phoneNumber1) 
        #checks to see if the phone number and the email is real
        if(phonenumbers.is_possible_number(phone_number) and valid_email(email)):
            return True
    return False


def createAccount(username,password,phoneNumber,email):
    #Need to check if the username already exists
    if(accountExists(username,email,phoneNumber)):
        try:
            #adds the users credentials into the database
            connection = sqlite3.connect('database.db')
            cur = connection.cursor()
            cur.execute("INSERT INTO users (username, pass, phone_number,email) VALUES (?, ? ,? , ?)",(username, password,phoneNumber,email))
            connection.commit()
            connection.close()
        except:
            print('An error has occured')
    else:
        print('account already exists')
        return redirect(url_for('makeAccount'))

       
   

        
def accountExists(username,email,phoneNumber):
    conn = get_db_connection()
    users = conn.execute('SELECT * FROM users WHERE EXISTS(SELECT * FROM users WHERE email=?)',(email,))
    conn.close()
    print(users)
    return users
    
def valid_email(email):
    #uses regular expressions to check if its a valid email address
  return bool(re.search(r"^[\w\.\+\-]+\@[\w]+\.[a-z]{2,3}$", email))

def loginValidation(email,password):
    #check if it is a valid email
    if(valid_email(email)):
        conn = get_db_connection()
        users = conn.execute('SELECT * FROM users WHERE EXISTS(SELECT * FROM users WHERE email=? AND password=?)',(email,password))
        conn.close()
        return users
    return False
    #Check db





